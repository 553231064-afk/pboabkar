/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package form;

import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Date;
import java.util.Calendar;
import config.koneksi;
import java.text.MessageFormat;  

public class FormTransaksi extends javax.swing.JFrame {

    private JTextField txtNim, txtIdBuku, txtTglPinjam, txtTglKembali, txtDenda;
    private JButton btnPinjam, btnKembali, btnRefresh, btnMenuUtama;
    private JTable tabelTransaksi;
    private DefaultTableModel model;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    
    public FormTransaksi() {
        setTitle("Transaksi Perpustakaan Digital");
        setSize(900, 700);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // --- 1. PANEL ATAS (Hanya Teks Input) ---
        JPanel panelAtas = new JPanel(new GridLayout(5, 2, 10, 10)); // 5 Baris
        panelAtas.setBorder(BorderFactory.createTitledBorder("Data Peminjaman"));
        panelAtas.setBorder(BorderFactory.createCompoundBorder(
            panelAtas.getBorder(), 
            BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));

        panelAtas.add(new JLabel("NIM Anggota:"));
        txtNim = new JTextField();
        panelAtas.add(txtNim);

        panelAtas.add(new JLabel("ID Buku (Angka):"));
        txtIdBuku = new JTextField();
        panelAtas.add(txtIdBuku);

        panelAtas.add(new JLabel("Tanggal Pinjam:"));
        txtTglPinjam = new JTextField();
        txtTglPinjam.setEditable(false);
        panelAtas.add(txtTglPinjam);

        panelAtas.add(new JLabel("Jatuh Tempo (7 Hari):"));
        txtTglKembali = new JTextField();
        txtTglKembali.setEditable(false);
        panelAtas.add(txtTglKembali);

        panelAtas.add(new JLabel("Denda Terhitung (Jika Terlambat):"));
        txtDenda = new JTextField("0");
        txtDenda.setEditable(false);
        panelAtas.add(txtDenda);

        // --- 2. PANEL TENGAH (Khusus Tombol - LEBAR) ---
        JPanel panelTombol = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panelTombol.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        btnPinjam = new JButton("Pinjam Buku");
        btnPinjam.setPreferredSize(new Dimension(150, 40));
        btnPinjam.setBackground(new Color(46, 204, 113));
        btnPinjam.setForeground(Color.WHITE);

        btnKembali = new JButton("Kembali Buku");
        btnKembali.setPreferredSize(new Dimension(150, 40));
        btnKembali.setBackground(new Color(231, 76, 60));
        btnKembali.setForeground(Color.WHITE);

        btnRefresh = new JButton("Refresh");
        btnRefresh.setPreferredSize(new Dimension(120, 40));

        btnMenuUtama = new JButton("Menu Utama");
        btnMenuUtama.setPreferredSize(new Dimension(150, 40));
        btnMenuUtama.setBackground(new Color(52, 73, 94));
        btnMenuUtama.setForeground(Color.WHITE);

        panelTombol.add(btnPinjam);
        panelTombol.add(btnKembali);
        panelTombol.add(btnRefresh);
        panelTombol.add(btnMenuUtama);

        // --- GABUNGKAN PANEL ATAS DAN TOMBOL ---
        JPanel panelContainer = new JPanel(new BorderLayout());
        panelContainer.add(panelAtas, BorderLayout.NORTH);
        panelContainer.add(panelTombol, BorderLayout.CENTER);

        // --- 3. TABEL ---
        tabelTransaksi = new JTable();
        JScrollPane scrollTable = new JScrollPane(tabelTransaksi);
        scrollTable.setBorder(BorderFactory.createTitledBorder("Daftar Buku Yang Sedang Dipinjam"));

        // Tambahkan ke Frame Utama
        add(panelContainer, BorderLayout.NORTH);
        add(scrollTable, BorderLayout.CENTER);

        // INISIALISASI DATA
        setTanggalOtomatis();
        tampilkanData();

        // --- EVENT HANDLING ---
        btnPinjam.addActionListener(e -> pinjamBuku());
        btnKembali.addActionListener(e -> kembalikanBuku());
        btnRefresh.addActionListener(e -> tampilkanData());
        btnMenuUtama.addActionListener(e -> {
            new MenuUtama().setVisible(true);
            this.dispose();
        });

        tabelTransaksi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pilihDataTabel();
            }
        });
    }

    private void setTanggalOtomatis() {
        Date hariIni = new Date();
        txtTglPinjam.setText(sdf.format(hariIni));
        Calendar cal = Calendar.getInstance();
        cal.setTime(hariIni);
        cal.add(Calendar.DAY_OF_MONTH, 7); 
        txtTglKembali.setText(sdf.format(cal.getTime()));
    }

    private void tampilkanData() {
        model = new DefaultTableModel();
        model.addColumn("ID Trans");
        model.addColumn("NIM");
        model.addColumn("ID Buku");
        model.addColumn("Pinjam");
        model.addColumn("Tempo");
        model.addColumn("Status");

        try {
            Connection conn = koneksi.configDB();
            String sql = "SELECT * FROM transaksi WHERE status='Dipinjam'";
            ResultSet rs = conn.createStatement().executeQuery(sql);
            while (rs.next()) {
                model.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(8)});
            }
            tabelTransaksi.setModel(model);
        } catch (Exception e) { System.out.println(e.getMessage()); }
    }

    private void pinjamBuku() {
        if(txtNim.getText().isEmpty() || txtIdBuku.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Isi NIM dan ID Buku!"); return;
        }
        try {
            Connection conn = koneksi.configDB();
            String sql = "INSERT INTO transaksi (nim, id_buku, tgl_pinjam, tgl_kembali, status) VALUES (?, ?, ?, ?, 'Dipinjam')";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, txtNim.getText());
            pst.setString(2, txtIdBuku.getText());
            pst.setString(3, txtTglPinjam.getText());
            pst.setString(4, txtTglKembali.getText());
            pst.execute();
            conn.createStatement().execute("UPDATE buku SET stok = stok - 1 WHERE id_buku = " + txtIdBuku.getText());
            JOptionPane.showMessageDialog(null, "Berhasil Pinjam!");
            tampilkanData();
            txtNim.setText(""); txtIdBuku.setText("");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, e.getMessage()); }
    }

    private void pilihDataTabel() {
        int baris = tabelTransaksi.getSelectedRow();
        if (baris != -1) {
            txtNim.setText(model.getValueAt(baris, 1).toString());
            txtIdBuku.setText(model.getValueAt(baris, 2).toString());
            try {
                Date tglJatuhTempo = sdf.parse(model.getValueAt(baris, 4).toString());
                Date sekarang = new Date();
                long selisih = sekarang.getTime() - tglJatuhTempo.getTime();
                long hari = selisih / (24 * 60 * 60 * 1000);
                if (hari > 0) txtDenda.setText(String.valueOf(hari * 1000));
                else txtDenda.setText("0");
            } catch (Exception e) {}
        }
    }

    private void kembalikanBuku() {
        int baris = tabelTransaksi.getSelectedRow();
        if (baris == -1) { JOptionPane.showMessageDialog(this, "Pilih data di tabel!"); return; }
        try {
            Connection conn = koneksi.configDB();
            String sql = "UPDATE transaksi SET tgl_dikembalikan = ?, denda = ?, status = 'Kembali' WHERE id_transaksi = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, sdf.format(new Date()));
            pst.setString(2, txtDenda.getText());
            pst.setString(3, model.getValueAt(baris, 0).toString());
            pst.execute();
            conn.createStatement().execute("UPDATE buku SET stok = stok + 1 WHERE id_buku = " + txtIdBuku.getText());
            JOptionPane.showMessageDialog(null, "Buku Kembali!");
            tampilkanData();
        } catch (Exception e) { JOptionPane.showMessageDialog(this, e.getMessage()); }
    }

    public void cetakLaporanSederhana() {
        try {
            MessageFormat h = new MessageFormat("LAPORAN TRANSAKSI");
            MessageFormat f = new MessageFormat("Halaman {0}");
            tabelTransaksi.print(JTable.PrintMode.FIT_WIDTH, h, f);
        } catch (Exception e) { JOptionPane.showMessageDialog(null, e.getMessage()); }
    }



    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
     public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FormTransaksi().setVisible(true));
    }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

