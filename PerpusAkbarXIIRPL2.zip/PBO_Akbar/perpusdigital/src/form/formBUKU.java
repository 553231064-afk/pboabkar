/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package form;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import config.koneksi;

public class formBUKU extends javax.swing.JFrame {

    private JTextField txtJudul, txtPenulis, txtKategori, txtStok, txtCari;
    private JButton btnSimpan, btnEdit, btnHapus, btnClear, btnKembali; 
    private JTable tabelBuku;
    private DefaultTableModel model;
    
    public formBUKU() {
        
        setTitle("Sistem Perpustakaan Digital - Manajemen Buku");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // --- Panel Form Input ---
        JPanel panelInput = new JPanel(new GridLayout(5, 2, 10, 10));
        panelInput.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));

        panelInput.add(new JLabel("Judul Buku:"));
        txtJudul = new JTextField();
        panelInput.add(txtJudul);

        panelInput.add(new JLabel("Penulis:"));
        txtPenulis = new JTextField();
        panelInput.add(txtPenulis);

        panelInput.add(new JLabel("Kategori:"));
        txtKategori = new JTextField();
        panelInput.add(txtKategori);

        panelInput.add(new JLabel("Stok:"));
        txtStok = new JTextField();
        panelInput.add(txtStok);

        // --- Panel Tombol ---
        JPanel panelTombol = new JPanel(new FlowLayout());
        btnSimpan = new JButton("Simpan");
        btnEdit = new JButton("Edit");
        btnHapus = new JButton("Hapus");
        btnClear = new JButton("Clear");
        btnKembali = new JButton("Kembali ke Menu"); // TAMBAHKAN INI
        btnKembali.setBackground(new Color(52, 73, 94)); // Warna gelap agar beda
        btnKembali.setForeground(Color.WHITE);
        panelTombol.add(btnKembali); // Masukkan ke panel yang sudah ada 
        panelTombol.add(btnSimpan);
        panelTombol.add(btnEdit);
        panelTombol.add(btnHapus);
        panelTombol.add(btnClear);
        panelInput.add(new JLabel("Aksi:"));
        panelInput.add(panelTombol);

        // --- Panel Pencarian & Tabel ---
        JPanel panelBawah = new JPanel(new BorderLayout(5, 5));
        panelBawah.setBorder(BorderFactory.createEmptyBorder(0, 20, 20, 20));

        JPanel panelCari = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelCari.add(new JLabel("Cari Buku (Judul/Penulis):"));
        txtCari = new JTextField(20);
        panelCari.add(txtCari);
        
        panelBawah.add(panelCari, BorderLayout.NORTH);

        tabelBuku = new JTable();
        panelBawah.add(new JScrollPane(tabelBuku), BorderLayout.CENTER);

        // Tambahkan ke Frame Utama
        add(panelInput, BorderLayout.NORTH);
        add(panelBawah, BorderLayout.CENTER);

        // --- EVENT HANDLING ---
        
        // Menampilkan Data saat Start
        tampilkanData("");

        // Tombol Simpan
        btnSimpan.addActionListener(e -> simpanData());

        // Tombol Edit
        btnEdit.addActionListener(e -> editData());

        // Tombol Hapus
        btnHapus.addActionListener(e -> hapusData());

        // Tombol Clear
        btnClear.addActionListener(e -> kosongkanForm());

        // Fitur Real-time Search (NILAI PLUS)
        txtCari.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                tampilkanData(txtCari.getText());
            }
        });

        // Klik Tabel untuk ambil data
        tabelBuku.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int baris = tabelBuku.getSelectedRow();
                txtJudul.setText(model.getValueAt(baris, 1).toString());
                txtPenulis.setText(model.getValueAt(baris, 2).toString());
                txtKategori.setText(model.getValueAt(baris, 3).toString());
                txtStok.setText(model.getValueAt(baris, 4).toString());
            }
        });
        // Di bagian Event Handling (bawah)
        btnKembali.addActionListener(e -> {
            new MenuUtama().setVisible(true); // Buka Menu Utama
            this.dispose(); // Tutup Form Buku
        });
    }
      private void tampilkanData(String cari) {
        model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Judul");
        model.addColumn("Penulis");
        model.addColumn("Kategori");
        model.addColumn("Stok");

        try {
            String sql = "SELECT * FROM buku WHERE judul LIKE '%" + cari + "%' OR penulis LIKE '%" + cari + "%'";
            Connection conn = koneksi.configDB();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("id_buku"), 
                    rs.getString("judul"), 
                    rs.getString("penulis"), 
                    rs.getString("id_kategori"), 
                    rs.getString("stok")
                });
            }
            tabelBuku.setModel(model);
        } catch (Exception e) {
            System.err.println("Gagal tampil data: " + e.getMessage());
        }
    }
     private void simpanData() {
        try {
            String sql = "INSERT INTO buku (judul, penulis, id_kategori, stok) VALUES (?, ?, ?, ?)";
            Connection conn = koneksi.configDB();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, txtJudul.getText());
            pst.setString(2, txtPenulis.getText());
            pst.setString(3, txtKategori.getText());
            pst.setString(4, txtStok.getText());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Berhasil Simpan!");
            tampilkanData("");
            kosongkanForm();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void editData() {
        try {
            // Edit berdasarkan judul sebagai contoh
            String sql = "UPDATE buku SET penulis=?, id_kategori=?, stok=? WHERE judul=?";
            Connection conn = koneksi.configDB();
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, txtPenulis.getText());
            pst.setString(2, txtKategori.getText());
            pst.setString(3, txtStok.getText());
            pst.setString(4, txtJudul.getText());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Berhasil Update!");
            tampilkanData("");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void hapusData() {
        int confirm = JOptionPane.showConfirmDialog(null, "Yakin hapus buku ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "DELETE FROM buku WHERE judul=?";
                Connection conn = koneksi.configDB();
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setString(1, txtJudul.getText());
                pst.execute();
                JOptionPane.showMessageDialog(null, "Berhasil Hapus!");
                tampilkanData("");
                kosongkanForm();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e.getMessage());
            }
        }
    }

    private void kosongkanForm() {
        txtJudul.setText("");
        txtPenulis.setText("");
        txtKategori.setText("");
        txtStok.setText("");
        txtCari.setText("");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
     public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new formBUKU().setVisible(true);
        });
    }
}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

