/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package form;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MenuUtama extends javax.swing.JFrame {

    public MenuUtama() {
        setTitle("Dashboard - Sistem Informasi Perpustakaan Digital");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // --- Panel Header ---
        JPanel panelHeader = new JPanel();
        panelHeader.setBackground(new Color(41, 128, 185)); // Warna Biru Modern
        panelHeader.setPreferredSize(new Dimension(800, 100));
        JLabel lblJudul = new JLabel("SISTEM INFORMASI PERPUSTAKAAN DIGITAL");
        lblJudul.setForeground(Color.WHITE);
        lblJudul.setFont(new Font("Segoe UI", Font.BOLD, 24));
        panelHeader.add(lblJudul);

        // --- Panel Menu (Tengah) ---
        JPanel panelMenu = new JPanel(new GridLayout(2, 2, 20, 20));
        panelMenu.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));

        // Tombol-tombol Menu
        JButton btnBuku = createMenuButton("MANAJEMEN BUKU", "📚");
        JButton btnAnggota = createMenuButton("MANAJEMEN ANGGOTA", "👥");
        JButton btnTransaksi = createMenuButton("TRANSAKSI (PINJAM/KEMBALI)", "🔄");
        JButton btnLaporan = createMenuButton("LAPORAN BULANAN", "📋");

        panelMenu.add(btnBuku);
        panelMenu.add(btnAnggota);
        panelMenu.add(btnTransaksi);
        panelMenu.add(btnLaporan);

        // --- Tombol Keluar ---
        JButton btnKeluar = new JButton("Keluar Aplikasi");
        btnKeluar.setBackground(new Color(192, 57, 43)); // Merah
        btnKeluar.setForeground(Color.WHITE);

        // --- Tambahkan ke Frame ---
        add(panelHeader, BorderLayout.NORTH);
        add(panelMenu, BorderLayout.CENTER);
        add(btnKeluar, BorderLayout.SOUTH);

        // --- EVENT HANDLING (NAVIGASI AKTIF) ---

        // Navigasi ke Form Buku
        btnBuku.addActionListener(e -> {
            new formBUKU().setVisible(true); // Pastikan nama class formBUKU sudah benar
            this.dispose(); 
        });

        // Navigasi ke Form Transaksi
        btnTransaksi.addActionListener(e -> {
            new FormTransaksi().setVisible(true);
            this.dispose();
        });

        // Navigasi ke Form Anggota (UPDATE BARU)
        btnAnggota.addActionListener(e -> {
            new FormAnggota().setVisible(true); // Membuka Form Anggota yang sudah dibuat
            this.dispose();
        });

        // Navigasi ke Cetak Laporan
        btnLaporan.addActionListener(e -> {
            // Memanggil fitur cetak dari Form Transaksi secara langsung
            FormTransaksi ft = new FormTransaksi();
            ft.cetakLaporanSederhana(); 
        });

        // Tombol Keluar
        btnKeluar.addActionListener(e -> {
            int pilih = JOptionPane.showConfirmDialog(null, "Yakin ingin keluar?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
            if(pilih == JOptionPane.YES_OPTION) System.exit(0);
        });
    }

    private JButton createMenuButton(String text, String icon) {
        JButton btn = new JButton("<html><center>" + icon + "<br>" + text + "</center></html>");
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setFocusPainted(false);
        btn.setBackground(Color.WHITE);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    public static void main(String[] args) {
        // Set Look and Feel agar tampilan mengikuti sistem operasi (lebih modern)
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {}
        
        SwingUtilities.invokeLater(() -> new MenuUtama().setVisible(true));
    }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

