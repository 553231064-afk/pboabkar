/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config; // Pastikan package-nya benar

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class koneksi {
    private static Connection mysqlconfig;
    
    public static Connection configDB() throws SQLException {
        try {
            // Ganti 'db_perpustakaan' dengan nama database yang kamu buat di XAMPP
            String url = "jdbc:mysql://localhost:3306/db_perpustakaan";
            String user = "root";
            String pass = ""; // Kosongkan jika pakai XAMPP standar
            
            // Registrasi driver (mencoba driver lama dan baru agar aman)
            try {
                Class.forName("com.mysql.cj.jdbc.Driver"); // Driver MySQL baru (v8.0+)
            } catch (ClassNotFoundException e) {
                Class.forName("com.mysql.jdbc.Driver"); // Driver MySQL lama (v5.1)
            }
            
            mysqlconfig = DriverManager.getConnection(url, user, pass);            
        } catch (Exception e) {
            System.err.println("Koneksi Gagal: " + e.getMessage());
        }
        return mysqlconfig;
    }
}